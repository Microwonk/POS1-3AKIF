import java.io.*;

public class Input {
    private int[] data;
    public Input(String file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            int ID = Integer.parseInt(br.readLine().split(" ")[1]);
            this.data = new int[ID];
            String line;
            while ((line = br.readLine()) != null) {
                String[] numbers = line.split(" ");
                ID = Integer.parseInt(numbers[0]);
                int scoreMax = Integer.parseInt(numbers[1]);
                if (this.data[ID] < scoreMax) {
                    this.data[ID] = scoreMax;
                }
                ID = Integer.parseInt(numbers[2]);
                scoreMax = Integer.parseInt(numbers[3]);
                if (this.data[ID] < scoreMax) {
                    this.data[ID] = scoreMax;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public int[] getData() {
        return this.data;
    }
}
