import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        start();
    }

    public static void start() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Which File do you want to scan for scores? (1-5)");
        int dec = Integer.parseInt(scan.nextLine());

        // Input inp = new Input("src/Input/level1_" + dec + ".in");
        Input inp = new Input("src/Input/level1_example.in");
        int[] data = inp.getData();

        System.out.println("Max Score is: " + findMax(data)[1] + " by the ID " + findMax(data)[0]);
    }

    public static int[] findMax(int[] array) {
        int max = array[0];
        int ID = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
                ID = i;
            }
        }
        return new int[]{ID, max};
    }

}