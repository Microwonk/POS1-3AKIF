import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Eingabe der Datei, 1-5");
        int input = Integer.parseInt(scan.nextLine());
        // Input inp = new Input("src/Input/level1_" + input + ".in");
        Input inp = new Input("src/Input/level1_example.in");
        int[] data = inp.getNums();

        System.out.println("Min Strom: " + findMin(data)[1] + " with the index of: " + findMin(data)[0]);
    }

    public static int[] findMin(int[] array) {
        int min = array[0];
        int index = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] < min) {
                min = array[i];
                index = i;
            }
        }
        return new int[]{index, min};
    }
}