import java.io.*;

public class Input {
    private String file;
    public Input(String file) {
        this.file = file;
    }

    public int[] getNums() {
        int[] toReturn = null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            toReturn = new int[Integer.parseInt(br.readLine())];
            int i = 0;
            while ((line = br.readLine()) != null) {
                toReturn[i] = Integer.parseInt(line);
                i++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return toReturn;
    }
}
