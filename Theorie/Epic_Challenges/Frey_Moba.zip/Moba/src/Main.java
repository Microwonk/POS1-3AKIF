import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        start();
    }

    public static void start() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Which File do you want to scan for scores? (1-5)");
        int dec = Integer.parseInt(scan.nextLine());

        LinkedList<int[]> data = new Input("src/Input/level1_" + dec + ".in");

        int size = 0;
        for (int[] score: data) {
            if (size < score[0]) {
                size = score[0];
            }
        }
        int[] IDScores = new int[size + 1]; // 0 - ID Max

        for (int[] score : data) {
            int i = score[0];
            IDScores[i] += score[1];
        }

        System.out.println("Max Score is: " + findMax(IDScores)[1] + " by the ID " + findMax(IDScores)[0]);
    }

    public static int[] findMax(int[] array) {
        int max = array[0];
        int index = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
                index = i;
            }
        }
        return new int[]{index, max};
    }

}