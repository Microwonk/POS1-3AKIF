import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;

public class Input extends LinkedList<int[]> {
    public Input(String file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] numbers = line.split(" ");

                int[] scores = new int[2];
                scores[0] = Integer.parseInt(numbers[0]);
                scores[1] = Integer.parseInt(numbers[1]);
                this.add(scores);

                scores = new int[2];
                scores[0] = Integer.parseInt(numbers[2]);
                scores[1] = Integer.parseInt(numbers[3]);
                this.add(scores);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
